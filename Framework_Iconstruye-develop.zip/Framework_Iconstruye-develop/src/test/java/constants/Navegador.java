package constants;

public enum Navegador {
    Chrome,  Edge, Firefox
}