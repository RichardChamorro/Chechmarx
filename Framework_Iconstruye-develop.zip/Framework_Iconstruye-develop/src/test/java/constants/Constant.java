package constants;

public class Constant {
	public static final String URL_Iconstruye_PROD = "https://www.iconstruye.com/";
	public static final String URL_Iconstruye_QA = "https://web-stage-scm.iconstruye.cl";


	
}
